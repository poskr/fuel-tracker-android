#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from fuel_app import FuelApp
if __name__ == "__main__":
    FuelApp().run()
